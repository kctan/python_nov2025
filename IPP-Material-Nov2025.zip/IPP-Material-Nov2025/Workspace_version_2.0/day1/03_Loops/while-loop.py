total = 0


start = 1
end = 10


current = start
while current <= end:
    print ("number: " + str(current))
    total = total + current 
    current = current + 1
  
print ("Total is " + str(total))
