size = input("Enter your T-shirt Size (s/m/l):")

if size == "s":
	print("You have chosen small size")
elif size == "m":
	print("You have chosen medium size")
else:
	print("You have chosen large size")