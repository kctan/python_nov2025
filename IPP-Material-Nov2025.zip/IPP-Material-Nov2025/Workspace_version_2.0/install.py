import subprocess
import sys

# replace "fpdf" with the library you plan to install
subprocess.check_call([sys.executable, "-m", "pip", "install", "fpdf"])
