#https://www.fortytwo.sg/dining/dining-tables/landon-regular-dining-table-coffee.html

from bs4 import BeautifulSoup
from urllib.request import Request, urlopen

#https://www.fortytwo.sg/landon-regular-dining-table-coffee.html
site = "https://www.fortytwo.sg/dining/dining-tables/landon-regular-dining-table-coffee.html"
hdr = {'User-Agent':'Mozilla/5.0'}
req = Request(site, headers=hdr)
page = urlopen(req)
soup = BeautifulSoup(page, 'html.parser')

'''
#requestObj = requests.get("https://www.fortytwo.sg/dining/dining-tables/landon-regular-dining-table-coffee.html")
requestObj.raise_for_status()
soup = bs4.BeautifulSoup(requestObj.text, 'html.parser')
'''

#product-price-46728 > span
elements = soup.select("#product-price-46728") # $69.90 
print("Current Price: " + elements[0].text)

#old-price-46728
elements = soup.select("#old-price-46728")  #  $129.90
print("\nOld Price: " + elements[0].text)

#edd > div > div > div.express-option.standard-option > div > div.earliest-delivery-date
#edd > div > div > div.express-option.standard-option > div > div.earliest-delivery-date > span
#essential-info-table > tbody > tr.lead-time.first.odd > td > div.estimates > div > strong
elements = soup.select("div[class='delivery est-date'] > strong")
print("\nDelivery: " + elements[0].text)
