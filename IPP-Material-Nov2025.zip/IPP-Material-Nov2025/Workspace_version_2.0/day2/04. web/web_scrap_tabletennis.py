from bs4 import BeautifulSoup
from urllib.request import Request, urlopen

site = "https://www.tabletennis11.com/other_eng/butterfly-viscaria"
hdr = {'User-Agent':'Mozilla/5.0'}
req = Request(site, headers=hdr)
page = urlopen(req)
soup = BeautifulSoup(page, 'html.parser')

#product-price-46728 > span
#product_addtocart_form > div.price-container.eng > div > div > span
elements = soup.select("#product_addtocart_form > div.price-container.eng > div > div > span") # $69.90 
print("Current Price: " + elements[0].text)

