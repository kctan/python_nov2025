import requests

url="https://api-open.data.gov.sg/v2/real-time/api/twenty-four-hr-forecast"
req=requests.get(url)
print(req.text)

