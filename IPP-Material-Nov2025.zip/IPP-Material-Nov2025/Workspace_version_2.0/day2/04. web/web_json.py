# https://www.site24x7.com/tools/jsonpath-finder-validator.html
# choose Bracket, Double Quotes
import json
import requests

url="https://api-open.data.gov.sg/v2/real-time/api/twenty-four-hr-forecast"

req=requests.get(url)

data = json.loads(req.text)

# print update timestamp
update_time = data["data"]["records"][0]["updatedTimestamp"]
print("Update time: " + update_time)

# print forecast
forecast = data["data"]["records"][0]["general"]["forecast"]["text"]
print("Forecast: " + forecast)


low_speed = data["data"]["records"][0]["general"]["wind"]["speed"]["low"]
print("low speed:", low_speed)


'''
helloFile = open("weather.txt", "a")
helloFile.write("Weather is " + forecast + "\n\n")
helloFile.close()

'''
'''
periods = data["items"][0]["periods"]

# printing all values
print("----------------- Print Info for different regions ------------------")
for period in periods:
    start = period["time"]["start"]
    #weather = forecast["forecast"]
    west_region = period["regions"]["west"]
    east_region = period["regions"]["east"]
    central_region = period["regions"]["central"]
    south_region = period["regions"]["south"]
    north_region = period["regions"]["north"]
            
    print(start)
    print("West Region: " + west_region)
    print("East Region: " + east_region)
    print("Central Region: " + central_region)
    print("South Region: " + south_region)
    print("North Region: " + north_region)
    
    print()
'''